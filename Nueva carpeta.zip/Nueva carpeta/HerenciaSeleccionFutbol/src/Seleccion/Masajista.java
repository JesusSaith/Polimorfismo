package Seleccion;


 
public class Masajista extends SeleccionFutbol {

	private String titulacion;

	private int aniosExperiencia;

	

	public Masajista(int id, String nombre, String apellidos, int edad, String titulacion, int aniosExperiencia) {
		super(id, nombre, apellidos, edad);
		this.titulacion = titulacion;
		this.aniosExperiencia = aniosExperiencia;
	}

	public String getTitulacion() {
		return titulacion;
	}

	public void setTitulacion(String titulacion) {
		this.titulacion = titulacion;
	}

	public int getAniosExperiencia() {
		return aniosExperiencia;
	}

	public void setAniosExperiencia(int aniosExperiencia) {
		this.aniosExperiencia = aniosExperiencia;
	}

	public void darMasaje() {
		System.out.println("Da un masaje");
                
        
       /** @Override
	public  String concentrase () {
            return "Viajar con el equipo";
            
        }
        @Override
        public String entrenar(){
             return "Dar masaje antes y despues del entrenamiento o partido";
         }
            */
        }

    @Override
    public String concentrease() {
        return "El Masajiste no entra a la concetracion";
        }
    @Override
    public String entrenar() {
        return "El Masajista no entrena pero da masajes antes y depues del entreno"; }
    

}
